__version__ = '0.5.3'

from .browser import RoboBrowser

__all__ = ['RoboBrowser']
